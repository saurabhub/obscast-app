@rem Gradle wrapper for Windows
@if "%DEBUG%"=="" @echo off
gradle %*
