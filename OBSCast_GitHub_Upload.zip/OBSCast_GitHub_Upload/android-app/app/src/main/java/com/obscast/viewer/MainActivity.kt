package com.obscast.viewer

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import kotlinx.coroutines.*

private const val STREAM_URL = "http://localhost:5000"
private const val RECONNECT_DELAY_MS = 2000L
private const val STATUS_HIDE_DELAY_MS = 4000L

// ── USB Receiver ──────────────────────────────────────────────────────────────
class UsbStateReceiver : BroadcastReceiver() {
    var onConnected: (() -> Unit)? = null
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.action) {
            "android.hardware.usb.action.USB_DEVICE_ATTACHED",
            "android.net.conn.CONNECTIVITY_CHANGE" -> onConnected?.invoke()
        }
    }
}

// ── Main Activity ─────────────────────────────────────────────────────────────
class MainActivity : ComponentActivity() {
    private var wakeLock: PowerManager.WakeLock? = null
    private val usbReceiver = UsbStateReceiver()
    private var webViewRef: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupImmersiveMode()
        acquireWakeLock()
        registerUsbReceiver()
        setContent {
            OBSCastTheme {
                OBSCastApp(
                    onWebViewCreated = { webViewRef = it },
                    onReconnect = { webViewRef?.reload() }
                )
            }
        }
    }

    private fun setupImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
            "OBSCast::StreamLock"
        )
        wakeLock?.acquire(8 * 60 * 60 * 1000L)
    }

    private fun registerUsbReceiver() {
        usbReceiver.onConnected = {
            android.os.Handler(mainLooper).postDelayed({ webViewRef?.reload() }, 1500)
        }
        val filter = IntentFilter().apply {
            addAction("android.hardware.usb.action.USB_DEVICE_ATTACHED")
            addAction("android.hardware.usb.action.USB_DEVICE_DETACHED")
            addAction("android.net.conn.CONNECTIVITY_CHANGE")
        }
        registerReceiver(usbReceiver, filter)
    }

    override fun onResume() { super.onResume(); setupImmersiveMode(); webViewRef?.onResume() }
    override fun onPause() { super.onPause(); webViewRef?.onPause() }
    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(usbReceiver) } catch (e: Exception) {}
        wakeLock?.release()
        webViewRef?.destroy()
    }
}

// ── Connection State ──────────────────────────────────────────────────────────
enum class ConnectionState { CONNECTING, CONNECTED, ERROR }

// ── Root App ──────────────────────────────────────────────────────────────────
@Composable
fun OBSCastApp(onWebViewCreated: (WebView) -> Unit, onReconnect: () -> Unit) {
    var state by remember { mutableStateOf(ConnectionState.CONNECTING) }
    var showOverlay by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(false) }
    var reconnectCount by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(state) {
        if (state == ConnectionState.CONNECTED) {
            delay(STATUS_HIDE_DELAY_MS); showOverlay = false
        } else { showOverlay = true }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black)
            .clickable { if (state == ConnectionState.CONNECTED) showControls = !showControls }
    ) {
        StreamWebView(
            url = STREAM_URL,
            onPageStarted = { state = ConnectionState.CONNECTING; showOverlay = true },
            onPageFinished = { state = ConnectionState.CONNECTED },
            onError = {
                state = ConnectionState.ERROR
                scope.launch { delay(RECONNECT_DELAY_MS); reconnectCount++; onReconnect() }
            },
            onWebViewCreated = onWebViewCreated
        )

        AnimatedVisibility(visible = showOverlay, enter = fadeIn(), exit = fadeOut()) {
            StatusOverlay(state = state, reconnectCount = reconnectCount)
        }

        AnimatedVisibility(
            visible = showControls && state == ConnectionState.CONNECTED,
            modifier = Modifier.align(Alignment.TopEnd),
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
        ) {
            ControlPanel(onReconnect = { onReconnect(); showControls = false }, onHide = { showControls = false })
        }

        if (state == ConnectionState.CONNECTED && !showOverlay) {
            LiveIndicator(modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
        }
    }
}

// ── WebView ───────────────────────────────────────────────────────────────────
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun StreamWebView(
    url: String,
    onPageStarted: () -> Unit,
    onPageFinished: () -> Unit,
    onError: () -> Unit,
    onWebViewCreated: (WebView) -> Unit
) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    builtInZoomControls = false
                    displayZoomControls = false
                    setSupportZoom(false)
                    cacheMode = WebSettings.LOAD_NO_CACHE
                    mediaPlaybackRequiresUserGesture = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                setBackgroundColor(Color.BLACK)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(v: WebView?, u: String?, f: android.graphics.Bitmap?) = onPageStarted()
                    override fun onPageFinished(v: WebView?, u: String?) {
                        onPageFinished()
                        evaluateJavascript("document.documentElement.style.overflow='hidden';", null)
                    }
                    override fun onReceivedError(v: WebView?, req: WebResourceRequest?, err: WebResourceError?) {
                        if (req?.isForMainFrame == true) onError()
                    }
                    @Suppress("DEPRECATION")
                    override fun onReceivedError(v: WebView?, code: Int, desc: String?, url: String?) = onError()
                }
                onWebViewCreated(this)
                loadUrl(url)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

// ── Status Overlay ────────────────────────────────────────────────────────────
@Composable
fun StatusOverlay(state: ConnectionState, reconnectCount: Int) {
    val green = androidx.compose.ui.graphics.Color(0xFF00D4AA)
    val yellow = androidx.compose.ui.graphics.Color(0xFFF5A623)
    val red = androidx.compose.ui.graphics.Color(0xFFE94560)
    val accent = androidx.compose.ui.graphics.Color(0xFF0F3460)
    val dark = androidx.compose.ui.graphics.Color(0xFF16213E)

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(
                androidx.compose.ui.graphics.Color(0xCC000000),
                androidx.compose.ui.graphics.Color(0xEE000000)
            ))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Box(
                modifier = Modifier.size(80.dp).clip(CircleShape).background(
                    when (state) {
                        ConnectionState.CONNECTED -> green
                        ConnectionState.CONNECTING -> yellow
                        ConnectionState.ERROR -> red
                    }
                ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (state) {
                        ConnectionState.CONNECTED -> Icons.Default.Videocam
                        ConnectionState.CONNECTING -> Icons.Default.Sync
                        ConnectionState.ERROR -> Icons.Default.WifiOff
                    },
                    contentDescription = null,
                    tint = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            Text("OBS Cast", color = androidx.compose.ui.graphics.Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

            Text(
                text = when (state) {
                    ConnectionState.CONNECTING -> "PC se connect ho raha hai..."
                    ConnectionState.CONNECTED -> "✓ Stream Connected!"
                    ConnectionState.ERROR -> "Connection fail — retry kar raha hai... ($reconnectCount)"
                },
                color = when (state) {
                    ConnectionState.CONNECTED -> green
                    ConnectionState.CONNECTING -> yellow
                    ConnectionState.ERROR -> red
                },
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )

            if (state != ConnectionState.CONNECTED) {
                LinearProgressIndicator(
                    modifier = Modifier.width(200.dp),
                    color = green,
                    trackColor = androidx.compose.ui.graphics.Color(0xFF333355)
                )
                Surface(color = dark, shape = RoundedCornerShape(12.dp), modifier = Modifier.padding(horizontal = 32.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        InstructionRow("1", "PC pe OBS Cast.exe chalao")
                        InstructionRow("2", "START STREAM click karo")
                        InstructionRow("3", "USB cable lagao (Debugging ON)")
                        InstructionRow("4", "ADB Reverse button dabao")
                        InstructionRow("5", "Stream automatically aayega")
                    }
                }
            }
        }
    }
}

@Composable
fun InstructionRow(step: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            modifier = Modifier.size(24.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(0xFF0F3460)),
            contentAlignment = Alignment.Center
        ) {
            Text(step, color = androidx.compose.ui.graphics.Color(0xFF00D4AA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(text, color = androidx.compose.ui.graphics.Color(0xFFCCCCCC), fontSize = 13.sp)
    }
}

// ── Live Indicator ────────────────────────────────────────────────────────────
@Composable
fun LiveIndicator(modifier: Modifier = Modifier) {
    var blink by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { while (true) { delay(800); blink = !blink } }
    Row(
        modifier = modifier.clip(RoundedCornerShape(20.dp))
            .background(androidx.compose.ui.graphics.Color(0xCC000000))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier.size(8.dp).clip(CircleShape).background(
                if (blink) androidx.compose.ui.graphics.Color(0xFFE94560)
                else androidx.compose.ui.graphics.Color.Transparent
            )
        )
        Text("LIVE", color = androidx.compose.ui.graphics.Color.White, fontSize = 10.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    }
}

// ── Control Panel ─────────────────────────────────────────────────────────────
@Composable
fun ControlPanel(onReconnect: () -> Unit, onHide: () -> Unit) {
    Surface(
        color = androidx.compose.ui.graphics.Color(0xEE1a1a2e),
        shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp),
        modifier = Modifier.padding(top = 40.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            CtrlBtn(Icons.Default.Refresh, "Refresh", onReconnect)
            CtrlBtn(Icons.Default.Close, "Close", onHide)
        }
    }
}

@Composable
fun CtrlBtn(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(8.dp)
    ) {
        Icon(icon, label, tint = androidx.compose.ui.graphics.Color(0xFF00D4AA), modifier = Modifier.size(24.dp))
        Text(label, color = androidx.compose.ui.graphics.Color(0xFF8899AA), fontSize = 9.sp)
    }
}

// ── Theme ─────────────────────────────────────────────────────────────────────
@Composable
fun OBSCastTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF00D4AA),
            background = androidx.compose.ui.graphics.Color.Black,
            surface = androidx.compose.ui.graphics.Color(0xFF16213E)
        ),
        content = content
    )
}
