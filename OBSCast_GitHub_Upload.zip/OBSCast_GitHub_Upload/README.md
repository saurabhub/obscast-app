# 📱 OBS Cast — GitHub Se APK Kaise Banayein

## ⚡ Ye ZIP GitHub pe upload karo → APK automatically ban jayega!

---

## 🔴 STEP 1 — GitHub Account Banao (Already hai toh skip karo)
1. https://github.com pe jao
2. **Sign Up** karo (free hai)
3. Email verify karo

---

## 🔴 STEP 2 — Naya Repository Banao
1. GitHub pe login karo
2. Top-right me **"+"** icon click karo → **"New repository"**
3. Repository name: `obscast-app`
4. **Public** select karo
5. **"Create repository"** click karo

---

## 🔴 STEP 3 — Files Upload Karo

### Method A — GitHub Website se (Easy, no Git needed):
1. Repository page pe **"uploading an existing file"** link click karo
2. Is ZIP ke andar se **SAARE files aur folders** drag & drop karo
   - `.github/` folder (hidden hai, show karo)
   - `android-app/` folder
   - `README.md`
3. Neeche **"Commit changes"** click karo

### Method B — Git Command Line se:
```bash
git clone https://github.com/AAPKA_USERNAME/obscast-app.git
# Sab files copy karo obscast-app/ folder mein
cd obscast-app
git add .
git commit -m "Add OBS Cast Android App"
git push
```

---

## 🔴 STEP 4 — Build Dekho (Automatic!)
1. Repository page pe **"Actions"** tab click karo
2. **"Build OBSCast APK"** workflow dikhega
3. Yellow circle = build chal raha hai ⏳
4. Green checkmark = APK ready! ✅
5. Red X = error (README ke neeche troubleshooting dekho)

> Build time: **~5-8 minutes** (pehli baar 15 min lag sakte hain)

---

## 🔴 STEP 5 — APK Download Karo
1. Actions tab mein green checkmark wali build pe click karo
2. Neeche **"Artifacts"** section mein:
3. **"OBSCast-v1.0-debug"** pe click karo → ZIP download hoga
4. ZIP extract karo → **`app-debug.apk`** milega!

---

## 🔴 STEP 6 — Phone Pe Install Karo

### Method A — Direct ADB se:
```bash
adb install app-debug.apk
```

### Method B — File Transfer:
1. APK file phone pe copy karo (USB ya WhatsApp se bhi bhej sakte ho)
2. Phone Settings → Security → **"Unknown Sources"** ON karo
   - Ya: Settings → Apps → Special Access → Install Unknown Apps → Chrome → Allow
3. File manager mein APK dhundo aur tap karo
4. **"Install"** press karo
5. **Done! OBS Cast app install ho gaya** 🎉

---

## ❓ Troubleshooting

**Build fail hua?**
- Actions tab mein failed build click karo
- "build-apk" step expand karo → error message dekho
- Common fix: Settings → Actions → "Allow all actions" enable karo

**APK install nahi ho raha?**
- Unknown Sources/Install Unknown Apps allow karo
- Phone restart karke dobara try karo

**App open hua par stream nahi aa raha?**
- PC pe OBS Cast.exe chalao aur START STREAM karo
- USB cable lagao aur ADB Reverse karo
- Android app automatically connect kar lega

---

## 📞 Support
Koi problem ho toh PC aur Android dono ka screenshot lo aur share karo.
